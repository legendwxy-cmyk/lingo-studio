# Lingo（AI 双语精听与跟读学习机）

自托管的 **视频自主拆解与英语精听学习机**（Playful 3D 柑橘旋钮学习机设计风格）。
支持上传任意英语视频或音频（可选 SRT/VTT 字幕），自动通过 5 步流水线拆解为双语精听、影子跟读对比、挖空回忆、听写检验、内置词典与跨篇词块复现课程。

## 架构概览

- **前端**（`frontend/`）：React 19 + Vite + 原生 Vanilla CSS Playful 3D 实体设计系统（默认「柑橘旋钮学习机」，支持 1 键切换「薰衣草工坊」「奶油陶瓷台」外壳皮肤）。
- **后端**（`backend/`）：FastAPI + SQLite (WAL) + FFmpeg + 双引擎自动拆解流水线：
  - **零密钥离线引擎**：FFmpeg 抽帧/音轨 + SRT/VTT 双语解析或本地 `faster-whisper` 断句转写 + CMUdict `eng_to_ipa` 音标 + 内置精选短语/词库 + 离线语音语法拆解与复述覆盖率批改。
  - **云端增强引擎**：在右上角「引擎」中配置 OpenAI / DeepSeek / 通义千问 / Groq / SiliconFlow / Gemini 兼容 API Key 后，自动启用云端 Whisper 词级时间戳、LLM 逐句精译、LLM 词典抽取与 AI 教练批改。

## 快速启动

### 方式一：单端口生产模式（一键构建前端并由 FastAPI 统一托管，端口 8000）
```bash
/home/antigravity/lingoreel/start.sh
```

### 方式二：前后端分离开发模式
```bash
# 终端 1：后端 API（端口 8000）
cd /home/antigravity/lingoreel/backend
.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000

# 终端 2：前端热更新（端口 5173）
cd /home/antigravity/lingoreel/frontend
npm run dev -- --host 0.0.0.0 --port 5173
```

## 核心流程

1. **资料库（含集成上传与 5 步拆解流水线）**：拖入 MP4/MOV/WebM/MP3/WAV/M4A 与可选 SRT/VTT 字幕（不传字幕也能用本地 `faster-whisper` 自动转写断句），实时查看「音画抽帧 → 断句转写 → 译文音标 → 词块抽取 → 词句绑定」进度，一键装入学习机。
2. **学习机**：球面 3D 倍速旋钮（0.5x–2.0x）、逐句按键、精确 AB 区间选择器、断点续播与字幕自动跟随、6 枚 3D 实体拨动开关（单句循环 / 逐句暂停 / 盲听 / IPA / AB 复读 / 画面字幕），右侧集成双语精听、跟读录音离线转写对比、挖空回忆、关键词与全句听写、重点词典与跨篇复现跳转、AI 精讲与语音口述复述、字幕增删校对与替换 SRT，以及可打印 PDF 讲义。
3. **生词本**：支持星标词汇与金句复习、3D 闪卡翻面抽查，以及 CSV / Anki TSV 导出。
